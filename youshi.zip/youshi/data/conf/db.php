<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'youshi',
    'DB_USER' => 'root',
    'DB_PWD' => 'nicai',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'v_',
    //密钥
    "AUTHCODE" => '7yrdskFh4FJvR4bVIB',
    //cookies
    "COOKIE_PREFIX" => 'QnlGeO_',
);
