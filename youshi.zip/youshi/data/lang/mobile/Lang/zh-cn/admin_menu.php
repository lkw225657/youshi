<?php
return array (
  'MOBILE_ADMIN_ADMIN' => '项目报名的流程查看',
  'MOBILE_ADMIN_CHONGZUO_AJAX' => '项目报名流程 重做',
  'MOBILE_ADMIN_SHOW_PHOTOS' => '项目流程 查看图片',
  'MOBILE_ADMIN_SHOW_VIDEOS' => '项目流程查看视频',
  'MOBILE_ADMIN_WANCHENG_AJAX' => '项目报名流程 现场测试修改',
);