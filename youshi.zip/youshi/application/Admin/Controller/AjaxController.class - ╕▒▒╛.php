<?php
namespace Admin\Controller;
use Common\Controller\AdminbaseController;
class AjaxController extends AdminbaseController{
	
	function _initialize() {
		parent::_initialize();
	}
	
	public function ajax_selectques_info()
	{
		//性别表（sexs）
		$sexs=sexs();		//获取标签
		$this->assign("sexs",$sexs);
		
		$id=$_REQUEST['id'];
		$model=M('selectques');
		$where['select_id']=$id;
		$selectques_info=$model->where($where)->find();
		$zimu=array('a','b','c','d','e','f','g','h');
		foreach($zimu as $k=>$v)
		{
			//echo $v.'111';
			if(!empty($selectques_info[$v]))
			{
				$html.='<div>';
				$html.='<b style=" font-size:14px !important;width: 15px; display: inline-block; text-align:center" class="zimu_b">'.strtoupper($v).'</b>';
				$html.='：<input type="text" name="post['.strtoupper($v).']" value="'.$selectques_info[$v].'" class="zimu_input" placeholder="请输入答案内容" style="width: 180px;">';
				$html.='<a class="btn" onClick="del(this)" href="javascript:">移除</a>';
				$html.=' <br>';
				$html.='</div>';
				$zimu_arr[$v]=$selectques_info[$v];
			}
		}
		$selectques_info['answer']=$zimu_arr;
		$selectques_info['html']=$html;
		echo json_encode($selectques_info);die;
	}
	
	//添加选择题
	public function ajax_select()
	{
		$model=M('ques');
		if (IS_POST) 
		{
			$array=I("post.post");
			$array['daan']=implode("|",$array['daan']);		//答案
			//vv($array);die;
			$zimu=array('a','b','c','d','e','f','g');
			foreach($zimu as $k=>$v)
			{
				if(empty($array[strtoupper($v)]))
				{
					$array[strtoupper($v)]='';
				}
			}
			
			//vv($array);die;
			if(empty($_POST['select_id']))
			{
				$array['add_time']=time();
				$result=$model->add($array);
				$select_info=$model->where(array('select_id'=>$result))->find();
			}else
			{
				$result=$model->where(array('select_id'=>$_POST['select_id']))->save($array);
				$select_info=$model->where(array('select_id'=>$_POST['select_id']))->find();
			}
			if ($result || !empty($select_info)) {
				
				
				$zimu=array('a','b','c','d','e','f','g','h');
				foreach($zimu as $k=>$v)
				{
					//echo $v.'111';
					if(!empty($select_info[$v]))
					{
						$zimu_arr[$v]=$select_info[$v];
					}
				}
				$select_info['answer']=$zimu_arr;
				vv($select_info);die;
				$hrml.='<tr>';
					$hrml.='<th width="80">选择题<?php echo $i;?></th>';
					$hrml.='<td style="line-height:45px;" >';
					$hrml.='<b style="font-size:18px; font-weight:bold"><span style=" width:66%; display:inline-block;">S'.$select_info['select_id'].'.'.$select_info['name'].'</span>';
					$hrml.='<a class="btn btn-danger" style="float:right; margin:0 0px 0 0" onClick="del(this)" href="javascript:">移除</a>';
					$hrml.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="select_edit(this,'.$select_info['select_id'].')" href="javascript:">修改</a>';
					$hrml.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="select_up(this)" href="javascript:">上移</a>';
					$hrml.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="select_down(this)" href="javascript:">下移</a>';
					$hrml.='</b>';
					$hrml.='<div id="ss">';
					$zimu=array('a','b','c','d','e','f','g','h');
					foreach($zimu as $k=>$v)
					{
						//echo $v.'111';
						if(!empty($select_info[$v]))
						{
							$hrml.='<div>';
							$hrml.='<label style="display:inline-block;">';
								$hrml.='<input type="checkbox" name="paper[s-'.$select_info['select_id'].'][]" value="'.strtoupper($v).'" data-direction="x" data-checklist="js-check-x" style="margin:0px;">';
							$hrml.='</label>';
							$hrml.='<b style=" font-size:14px !important;width: 15px; display: inline-block; text-align:center" class="zimu_b">'.strtoupper($v).'</b>';
							$hrml.='：<span style="width:333px; display: inline-block">'.$select_info[$v].'</span>';
							 $hrml.='<br>';
							$hrml.='</div>';
						}
						
					}
					$hrml.='</div>';
					$hrml.='</td>';
				$hrml.='</tr>';
				echo $hrml;die;
				//vv($select_info);die;
				$this->success("操作成功！");
			} else {
				$this->error("操作失败！");
			}
			//print_r($article);
		}
		//$this->display();
	}
	
	//添加问答题
	public function ajax_answer()
	{
		$model=M('answerques');
		if (IS_POST) 
		{
			$array=I("post.post");
			
			if(empty($_POST['id']))
			{
				$array['add_time']=time();
				$result=$model->add($array);
				$answer_info=$model->where(array('answer_id'=>$result))->find();
			}else
			{
				$result=$model->where(array('answer_id'=>$_POST['id']))->save($array);
				$answer_info=$model->where(array('answer_id'=>$_POST['answer_id']))->find();
			}
			
			if ($result || !empty($answer_info)) {
				$html.='<tr>';
					$html.='<th width="80">问答题</th>';
					$html.='<td style="line-height:45px;" >';
					$html.='<b style="font-size:18px; font-weight:bold">A'.$answer_info['answer_id'].'.'.$answer_info['name'];
					$html.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="del(this)" href="javascript:">移除</a>';
					$html.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="answer_up(this)" href="javascript:">上移</a>';
					$html.='<a class="btn btn-danger" style="float:right; margin:0 10px 0 0" onClick="answer_down(this)" href="javascript:">下移</a>';
					$html.='</b>';
					$html.='<div id="ss">';
					$html.='<input type="hidden" name="answer[]" value="'.$answer_info['answer_id'].'">';
					$html.='<textarea name="" id="description" style="width: 50%; height: 100px;" disabled placeholder="请填写备注（备注可以写问答答案提示）">'.$answer_info['answer_desc'].'</textarea>';
					$html.='</div>';
					$html.='</td>';
				$html.='</tr>';
				echo $html;die;
				$this->success("操作成功！");
			} else {
				$this->error("操作失败！");
			}
			//print_r($article);
		}
	}
	
	
	//ajax获取项目编号
	public function ajax_project_no()
	{
		//$project_type_code=;
		if($_POST['type']!=4)
		{
			//获取项目类型
			$class=M('class');
			$class_info=$class->where(array('parent_id'=>2,'name'=>$_POST['project_type']))->find();
			
			$project_class_info=$class->where(array('parent_id'=>3,'name'=>$_POST['project_class']))->find();
			
			//获取客户
			$kehu_info=$class->where(array('parent_id'=>1,'name'=>$_POST['kehu']))->find();
			
			//判断客户的第几个项目
			$project=M('project');
			$project_num=$project->where(array('kehu'=>$_POST['kehu'],'type'=>$_POST['type']))->count();
			
			echo project_type_code($_POST['type']).$class_info['code'].date("y",time()).$kehu_info['code'].sprintf("%02d",$project_num+1);
		}else
		{
			//获取项目类型
			$class=M('class');
			$class_info=$class->where(array('parent_id'=>3,'name'=>$_POST['project_class']))->find();
			
			//判断客户的第几个项目
			$project=M('project');
			$project_num=$project->where(array('project_type'=>$_POST['project_class']))->count();
			//vv($_POST);
			//vv($project_num);
			echo project_type_code($_POST['type']).date("y",time()).$class_info['code'].sprintf("%02d",$project_num+1);
			
		}
	}
	
	//日期ajax
	//ajax area
	public function ajax_area()
	{
		$area_id=$_REQUEST['area_id'];
		$area_parent_id=$_REQUEST['area_parent_id'];
		$area=M('area');
		$where['area_parent_id']=$area_parent_id;
		//$where['area_id']=$area_id;
		
		$area_info=$area->field('area_id,area_name')->where($where)->select();
		$area_str='<option value="">请选择</option>';
		foreach($area_info as $k=>$v)
		{
			if($area_id==$v['area_id'])
			{
				$selected='selected';
			}else
			{
				$selected='';
			}
			$area_str.='<option value="'.$v['area_id'].'" '.$selected.'>'.$v['area_name'].'</option>';
			
		}
		echo $area_str;die;
	}
	
}